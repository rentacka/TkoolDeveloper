﻿namespace jsCallEditor
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.SourceTextBox = new System.Windows.Forms.TextBox();
            this.InputResultTextBox = new System.Windows.Forms.TextBox();
            this.JsToUnityButton = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ProjPathApllyButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ProjPathTextBox = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(661, 500);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl2);
            this.tabPage3.Controls.Add(this.InputResultTextBox);
            this.tabPage3.Controls.Add(this.JsToUnityButton);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(653, 474);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "ディープランニング";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Location = new System.Drawing.Point(10, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(637, 238);
            this.tabControl2.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.SourceTextBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(629, 212);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Javascriptから";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // SourceTextBox
            // 
            this.SourceTextBox.AcceptsReturn = true;
            this.SourceTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SourceTextBox.Location = new System.Drawing.Point(3, 3);
            this.SourceTextBox.Multiline = true;
            this.SourceTextBox.Name = "SourceTextBox";
            this.SourceTextBox.Size = new System.Drawing.Size(623, 206);
            this.SourceTextBox.TabIndex = 12;
            // 
            // InputResultTextBox
            // 
            this.InputResultTextBox.AcceptsReturn = true;
            this.InputResultTextBox.Location = new System.Drawing.Point(101, 262);
            this.InputResultTextBox.Multiline = true;
            this.InputResultTextBox.Name = "InputResultTextBox";
            this.InputResultTextBox.ReadOnly = true;
            this.InputResultTextBox.Size = new System.Drawing.Size(546, 209);
            this.InputResultTextBox.TabIndex = 12;
            // 
            // JsToUnityButton
            // 
            this.JsToUnityButton.Location = new System.Drawing.Point(8, 293);
            this.JsToUnityButton.Name = "JsToUnityButton";
            this.JsToUnityButton.Size = new System.Drawing.Size(77, 23);
            this.JsToUnityButton.TabIndex = 6;
            this.JsToUnityButton.Text = "Unityへ変換";
            this.JsToUnityButton.UseVisualStyleBackColor = true;
            this.JsToUnityButton.Click += new System.EventHandler(this.JsToUnityButton_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.ProjPathApllyButton);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.ProjPathTextBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(653, 474);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "設定";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "↓index.htmlがあるフォルダを指定してください";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(777, 356);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // ProjPathApllyButton
            // 
            this.ProjPathApllyButton.Location = new System.Drawing.Point(713, 4);
            this.ProjPathApllyButton.Name = "ProjPathApllyButton";
            this.ProjPathApllyButton.Size = new System.Drawing.Size(75, 23);
            this.ProjPathApllyButton.TabIndex = 2;
            this.ProjPathApllyButton.Text = "適用";
            this.ProjPathApllyButton.UseVisualStyleBackColor = true;
            this.ProjPathApllyButton.Click += new System.EventHandler(this.ProjPathApllyButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "プロジェクトパス";
            // 
            // ProjPathTextBox
            // 
            this.ProjPathTextBox.Location = new System.Drawing.Point(100, 6);
            this.ProjPathTextBox.Name = "ProjPathTextBox";
            this.ProjPathTextBox.Size = new System.Drawing.Size(606, 19);
            this.ProjPathTextBox.TabIndex = 0;
            this.ProjPathTextBox.Text = "D:\\Mydocument\\RPGMV\\Test\\Test";
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(653, 474);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "テスト学習";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 500);
            this.Controls.Add(this.tabControl1);
            this.Name = "MainForm";
            this.Text = "MVをUnityにもUE4にも変換できるソフト";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ProjPathTextBox;
        private System.Windows.Forms.Button ProjPathApllyButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button JsToUnityButton;
        public System.Windows.Forms.TextBox InputResultTextBox;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox SourceTextBox;
        private System.Windows.Forms.TabPage tabPage4;
    }
}

