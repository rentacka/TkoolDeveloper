﻿using Accord.Neuro.Learning;
using Accord.Neuro.Networks;
using CefSharp;
using CefSharp.WinForms;
using Word2Vec.Net;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Jint.Parser;
using Jint.Parser.Ast;

namespace jsCallEditor
{
    public partial class MainForm : Form
    {
        public static MainForm Main;

        public static string prjDir = @"D:\Mydocument\RPGMV\オクタゴンさん\CodeLanguage\bin\Debug\Test\Test";

        TkoolJson tkoolJson = new TkoolJson();

        public MainForm()
        {
            InitializeComponent();

            Main = this;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(
                "TkoolMapJs/YEP_RegionRestrictions.js", Encoding.GetEncoding("Shift_JIS"));
            var text = sr.ReadToEnd();
            sr.Close();

            //TODO:JsTextBox.Text = text;

            var testRefForm = new RefarenceSearcher();
            testRefForm.TopLevel = false;
            tabPage4.Controls.Add(testRefForm);
            testRefForm.FormBorderStyle = FormBorderStyle.None;
            testRefForm.Dock = DockStyle.Fill;
            testRefForm.Show();
        }

        private void ProjPathApllyButton_Click(object sender, EventArgs e)
        {
            prjDir = ProjPathTextBox.Text;
        }

        private void JsToUnityButton_Click(object sender, EventArgs e)
        {
            // word2vecのword-analogyを可視化した
            //file:///E:/Mydocument/My%20eBooks/EverBook/data/20161231174857/index.html
            //https://github.com/nishio/word2vec-analogy-vis/blob/master/word-analogy.py#L8

            // ベクトルをWordAnalogyでグラフ化
            // それで、同じ単語(クラスタ)を変換するだけ
            //var analogy = new WordAnalogy(outputFileName);
            //bestwords = analogy.Search("Use");

            // C#からUnityC#へ変換
            //ResultCSharpTextBox.Text;
        }
    }
}
