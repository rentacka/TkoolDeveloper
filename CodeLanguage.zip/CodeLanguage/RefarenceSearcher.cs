﻿using Accord.Neuro.Learning;
using Accord.Neuro.Networks;
using CefSharp;
using CefSharp.WinForms;
using Word2Vec.Net;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Jint.Parser;
using Jint.Parser.Ast;
using System.Xml.Linq;
using System.IO.Compression;

namespace jsCallEditor
{
    public partial class RefarenceSearcher : Form
    {
        HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
        ObjectEnumrator objrator = new ObjectEnumrator();

        public RefarenceSearcher()
        {
            InitializeComponent();
        }

        #region Vector化
        // ソースコードからASTを抽出
        // それをディープランニングをつかて、関数を特定し、手動で変換になるはず
        // できん部分はユーザーが編集できるようにしとく

        Distance tkoolVector;
        Distance CsharpVector;
        Distance unityVector;
        private void TkookMVGakushuButton_Click(object sender, EventArgs e)
        {
            tkoolVector = DistanceWorld2.ToVectorFromFile("TkoolMVGakushu.text");
        }

        private void UnityGakushuButton_Click(object sender, EventArgs e)
        {
            unityVector = DistanceWorld2.ToVectorFile("");
        }

        private void CsharpGakushuButton_Click(object sender, EventArgs e)
        {
            // C#構造の学習
            // タイトルかサマリーの学習

            //CsharpVector = DistanceWorld2.ToVectorFile("");
        }

        private void VectorTestButton_Click(object sender, EventArgs e)
        {
            // ツクールMVとUnityとC#のベクトルが必要

            // ・機能の比較には特定の言葉を比較して、BestWordで木構造を出力して比較するだけ。
            //クラスタの特定は比率で求まるはず
        }
        #endregion Vector化

        string[] GetHelpFolders()
        {
            string[] subFolders = System.IO.Directory.GetDirectories(@"E:\Mydocument\RPGMV\オクタゴンさん\CodeLanguage\bin\x86\Debug\MSDN Help Jp", "*", System.IO.SearchOption.TopDirectoryOnly);
            return subFolders;
        }

        #region C#Json化と最適化と構造化
        private void CshparJsonbutton_Click(object sender, EventArgs e)
        {
            string[] subFolders = GetHelpFolders();

            List<EntryHtml> titleList = new List<EntryHtml>();
            foreach (var folder in subFolders)
            {
                var di = new DirectoryInfo(folder);
                var zipPath = Path.Combine(folder, di.Name + ".mshc");

                using (ZipArchive a = ZipFile.OpenRead(zipPath))
                {
                    foreach (var entry in a.Entries)
                    {
                        if (entry.Name.EndsWith(".htm"))
                        {
                            var stream = entry.Open();

                            StreamReader sr = new StreamReader(stream,
                                //Encoding.GetEncoding("Shift_JIS"));
                                Encoding.UTF8);
                            var text = sr.ReadToEndAsync();

                            text.Wait();
                            var littleHtml = HtmlSmart.GetLittleHtml(text.Result);
                            htmlDoc.LoadHtml(littleHtml);
                            stream.Close();

                            var htmlTitle = HtmlSmart.GetHtmlTitle(htmlDoc.DocumentNode);
                            var htmlTitleClass = HtmlSmart.GetHtmlTitleClass(htmlDoc.DocumentNode);
                            var summury = HtmlSmart.GetHmltSummury(htmlDoc.DocumentNode);
                            //var href = summury.href;
                            string sumText = null;
                            if (summury != null)
                                sumText = summury.summury;
                            var nameSpace = HtmlSmart.GetNamespaseLoad(littleHtml);
                            var entryHtml = new EntryHtml()
                            {
                                Title = htmlTitleClass,
                                HtmlTitle = htmlTitle,
                                NameSpace = nameSpace
                                ,
                                Summury = sumText
                                //,FileName = entry.Name, ZipPath = zipPath
                            };
                            titleList.Add(entryHtml);
                        }
                    }
                }
            }

            List<string> JsonList = new List<string>();
            // titleListを保存
            foreach (var entryHtml in titleList)
            {
                entryHtml.TrimError();

                var json = CsarpDocJson.Serialize(entryHtml);
                JsonList.Add(json);
            }

            CsarpDocJson.SerializeFile(JsonList, "csharp.data");
        }

        // C#最適化
        private void CsharpSmartbutton_Click(object sender, EventArgs e)
        {
            CsarpDocJson.UnicodeSmartData();
        }

        private void CSharpTreebutton_Click(object sender, EventArgs e)
        {
            var entryHtmls = CsarpDocJson.DeSerializeEntryHtml();
            List<EntryHtml.Syntax> syntaxs = new List<EntryHtml.Syntax>();
            foreach (var entry in entryHtmls)
            {
                var syntax = entry.ToSyntax();
                if(syntax.Namespace!=null && syntax.ClassName != null && syntax.Name != null)
                    syntaxs.Add(syntax);
            }

            Dictionary<string, List<EntryHtml.Syntax>> dic = new Dictionary<string, List<EntryHtml.Syntax>>();
            foreach (var syntax in syntaxs)
            {
                // ネームスペースが同じものを集計

                if (dic.ContainsKey(syntax.Namespace) == false)
                {
                    var list = new List<EntryHtml.Syntax>();
                    dic.Add(syntax.Namespace, list);
                }
                else
                {
                    foreach (var child in dic)
                    {
                        if (child.Key == syntax.Namespace)
                        {
                            child.Value.Add(syntax);
                            break;
                        }
                    }
                }
            }
        }
        #endregion  C#Json化と最適化と構造化

        private void TkoolInitbutton_Click(object sender, EventArgs e)
        {
            var pluginFolda = Path.Combine(Application.StartupPath, "InputJs");
            var jsFiles = Directory.GetFileSystemEntries(pluginFolda, "*.js", SearchOption.AllDirectories);

            // ObjectEnumrater.jsをコピーして作成
            var src = Application.StartupPath;
            var pastePath = Path.Combine(src, @"InputJs\ObjectEnumrator.js");
            //if(File.Exists(pastePath) == false)
            File.Copy(Path.Combine(src, "ObjectEnumrator.js"), pastePath, true);

            // Index.html作成
            StringBuilder scriptBuns = new StringBuilder();
            scriptBuns.AppendLine("<!DOCTYPE html><html><head>");
            foreach (var file in jsFiles)
            {
                var fi = new FileInfo(file);
                if (fi.Name != "ObjectEnumrator.js")
                    scriptBuns.AppendLine(getScriptBun("InputJs/" + fi.Name));
            }
            scriptBuns.AppendLine(getScriptBun("InputJs/ObjectEnumrator.js"));
            scriptBuns.AppendLine("</head><body></body></html>");

            System.IO.StreamWriter sw = new System.IO.StreamWriter(
                Path.Combine(Application.StartupPath, "index.html"),
                false,
                //System.Text.Encoding.GetEncoding("shift_jis"));
                System.Text.Encoding.UTF8);
            sw.Write(scriptBuns.ToString());
            sw.Close();

            //objrator.ScrinptCef.Load("file:///E:/Mydocument/RPGMV/%E3%82%AA%E3%82%AF%E3%82%BF%E3%82%B4%E3%83%B3%E3%81%95%E3%82%93/CodeLanguage/bin/x86/Debug/index.html");

            var ScrinptCef = objrator.InitCef("file:///E:/Mydocument/RPGMV/%E3%82%AA%E3%82%AF%E3%82%BF%E3%82%B4%E3%83%B3%E3%81%95%E3%82%93/CodeLanguage/bin/x86/Debug/index.html");
            tabPage3.Controls.Add(ScrinptCef);
            //Controls.Add(ScrinptCef);
        }

        private void TkoolMVJsonbutton_Click(object sender, EventArgs e)
        {
            /*
Utils
Graphics
Input
TouchInput
Html5Audio
JsonEx
DataManager
ConfigManager
StorageManager
ImageManager
AudioManager
SoundManager
TextManager
SceneManager
BattleManager
PluginManager

var $dataActors       = null;
var $dataClasses      = null;
var $dataSkills       = null;
var $dataItems        = null;
var $dataWeapons      = null;
var $dataArmors       = null;
var $dataEnemies      = null;
var $dataTroops       = null;
var $dataStates       = null;
var $dataAnimations   = null;
var $dataTilesets     = null;
var $dataCommonEvents = null;
var $dataSystem       = null;
var $dataMapInfos     = null;
var $dataMap          = null;
var $gameTemp         = null;
var $gameSystem       = null;
var $gameScreen       = null;
var $gameTimer        = null;
var $gameMessage      = null;
var $gameSwitches     = null;
var $gameVariables    = null;
var $gameSelfSwitches = null;
var $gameActors       = null;
var $gameParty        = null;
var $gameTroop        = null;
var $gameMap          = null;
var $gamePlayer       = null;
var $testEvent        = null;
             */

            //var parser = new JavaScriptParser();
            //parser.Parse();

            var result = objrator.Do("$gameTroop");

            Console.WriteLine(result);
            Console.WriteLine("動作完了");
        }

        string getScriptBun(string path)
        {
            string script = "<script type=" + @"""" + "text/javascript" + @"""" + " src=" + @"""" + path + @"""" + "></script>";

            return script;
        }

        private void TkoolMVTreebutton_Click(object sender, EventArgs e)
        {
        }

        private void UnityJsonbutton_Click(object sender, EventArgs e)
        {
            // Unity構造の取得
            UnityDocJson unityDocJson = new UnityDocJson();
            var tocDoc = unityDocJson.DeSerializeToc();

            // TODO:Htmlからテキストを取得して、説明文のみ抽出
            // 「説明」以下の部分やったかな？
            //foreach(var doc in tocDoc)
            //var content  = HtmlToText.GetHtmlTextFromStr(doc.DocumentNode.InnerText);
        }

        private void UnityTreebutton_Click(object sender, EventArgs e)
        {

        }

        private void RefarenceSearcher_Load(object sender, EventArgs e)
        {

        }
    }
}
