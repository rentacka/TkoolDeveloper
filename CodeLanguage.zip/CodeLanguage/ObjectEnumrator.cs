﻿using Accord.Neuro.Learning;
using Accord.Neuro.Networks;
using CefSharp;
using CefSharp.WinForms;
using Word2Vec.Net;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Jint.Parser;
using Jint.Parser.Ast;
using System.Xml.Linq;
using System.IO.Compression;

namespace jsCallEditor
{
    class ObjectEnumrator
    {
        public ChromiumWebBrowser ScrinptCef;

        public ChromiumWebBrowser InitCef(string url)
        {
            CefSettings settings = new CefSettings();
            //settings.WindowlessRenderingEnabled = true;
            Cef.Initialize(settings);

            ScrinptCef = new ChromiumWebBrowser(url);
            ScrinptCef.BrowserSettings.WebSecurity = CefState.Disabled;
            ScrinptCef.BrowserSettings.Javascript = CefState.Enabled;
            ScrinptCef.BrowserSettings.FileAccessFromFileUrls = CefState.Enabled;
            ScrinptCef.BrowserSettings.UniversalAccessFromFileUrls = CefState.Enabled;

            ScrinptCef.Visible = true;
            ScrinptCef.Width = 300;
            ScrinptCef.Height = 300;
            ScrinptCef.Dock = DockStyle.Fill;

            return ScrinptCef;
        }

        string  ReturnTaskJs(Task<JavascriptResponse> task)
        {
            string ScriptResult = null;

            task.Wait();
            ScriptResult = task.Result.Result as string;

            return ScriptResult;
        }

        public string Do(string objName)
        {
            ScrinptCef.ExecuteScriptAsync("GetObject", objName);
            //ScrinptCef.ExecuteScriptAsync("GetObjectChains", objName);

            var task0 = ScrinptCef.EvaluateScriptAsync("(function() {" + "return document.title" + "; })();");
            var reValue = ReturnTaskJs(task0);

            return reValue;
        }
    }
}
