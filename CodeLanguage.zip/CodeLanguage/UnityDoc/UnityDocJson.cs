using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace jsCallEditor
{
	internal class UnityDocJson
	{
        static string unityDocPath = null;
        private static string DataDir
		{
			get
			{
                if (unityDocPath == null)
                {
                    var unity64DocPath = @"C:\Program Files\Unity 5.6.0b3\Editor\Data\Documentation\en\ScriptReference";
                    var unity32DocPath = @"C:\Program Files (x86)\Unity 5.6.0b3\Editor\Data\Documentation\en\ScriptReference";

                    if (Directory.Exists(unity32DocPath))
                        unityDocPath = unity32DocPath;
                    if (Directory.Exists(unity64DocPath))
                        unityDocPath = unity64DocPath;
                }

                // Unity�̃��t�@�����X�t�H���_
                var docdata = Path.Combine(unityDocPath, "docdata");

                return docdata;
			}
		}

		public DocLink DeSerializeToc()
		{
			string str = "toc";
			return this.DeserializeFromFile<DocLink>(Path.Combine(UnityDocJson.DataDir, str + ".json"));
		}

		public T DeserializeFromFile<T>(string path)
		{
			return JsonConvert.DeserializeObject<T>(UnityDocJson.ReadText(path));
		}

		private static string ReadText(string path)
		{
			StreamReader expr_0B = new StreamReader(path, Encoding.UTF8);
			string result = expr_0B.ReadToEnd();
			expr_0B.Close();
			return result;
		}

		private static string ConvertEncoding(string src, Encoding destEnc)
		{
			Encoding expr_05 = Encoding.ASCII;
			byte[] bytes = expr_05.GetBytes(src);
			byte[] bytes2 = Encoding.Convert(expr_05, destEnc, bytes);
			return destEnc.GetString(bytes2);
		}
	}
}
