﻿using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;
using System.Collections.Generic;
using Newtonsoft.Json;
using HtmlAgilityPack;
using System;

namespace jsCallEditor
{
    public class EntryHtml
    {
        [JsonProperty("Title")]
        public string Title { get; set; }

        [JsonProperty("htmlTitle")]
        public string HtmlTitle { get; set; }

        [JsonProperty("nameSpace")]
        public string NameSpace { get; set; }

        [JsonProperty("Summury")]
        public string Summury { get; set; }

        [JsonProperty("FileName")]
        public string FileName { get; set; }

        [JsonProperty("ZipPath")]
        public string ZipPath { get; set; }

        // TODO:TrimError
        public void TrimError()
        {
            if(null!= Title)
                Title = Title.Replace(@"""","").Replace(@"}","").Replace(@"{", "").Replace("'", "").Replace("?", "").Replace(@"\", "");
            if (null != HtmlTitle)
                HtmlTitle = HtmlTitle.Replace(@"""", "").Replace(@"}", "").Replace(@"{", "").Replace("'", "").Replace("?", "").Replace(@"\", "");
            if (null != NameSpace)
                NameSpace = NameSpace.Replace(@"""", "").Replace(@"}", "").Replace(@"{", "").Replace("'", "").Replace("?", "").Replace(@"\", "");
            if (null != Summury)
                Summury = Summury.Replace(@"""", "").Replace(@"}", "").Replace(@"{", "").Replace("'", "").Replace("?", "").Replace(@"\", "");
        }

        public class Syntax
        {
            public string Namespace;
            public string ClassName;
            public string FiealdType;
            public string Name;

            public string Summury;
        }

        public Syntax ToSyntax()
        {
            Syntax syntax = new Syntax();
            if (Title != null && Title.Length > 0)
            {
                // HTMLから(複数の)titleタグを探す
                var SyntaxArray = Title.Split(" ".ToCharArray());

                if (SyntaxArray[0].Contains(".") && SyntaxArray.Length >= 3)
                {
                    var ClassAndName = SyntaxArray[0].Split(".".ToCharArray());
                    syntax.ClassName = ClassAndName[0];
                    syntax.Name = ClassAndName[1];

                    syntax.FiealdType = SyntaxArray[1];
                }
                else
                {
                    syntax.ClassName = SyntaxArray[0];
                    syntax.FiealdType = "";
                }
            }

            syntax.Namespace = NameSpace;
            syntax.Summury = Summury;

            return syntax;
        }
    }
}
