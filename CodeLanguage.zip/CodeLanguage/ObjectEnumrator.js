﻿
function GetObject(propName)
{
    var obj1 = JSON.parse(JSON.stringify(propName));

    // プロトタイプの列挙出来ないキーも取得する
    var names2 = Object.getOwnPropertyNames(obj1);
    var proto = Object.getPrototypeOf(obj1);
    if (proto && proto !== Object.prototype) {
        names2 = names2.concat(Object.getOwnPropertyNames(proto));
    }
    document.title = names2;

    /*
    // プロトタイプの列挙出来ないキーも取得する
    var names2 = Object.getOwnPropertyNames(obj1);
    var proto = Object.getPrototypeOf(obj1);
    var protoNames = Object.getOwnPropertyNames(proto)

    for (var key in protoNames) {
        var keyObj = proto[key];
        //var type = typeof keyObj;

        //str += join(propName, key) + ' : ' + type + " ";
        str += keyObj;
    }

    document.title = str;
    */
}

function isString(obj) {
    return typeof (obj) == "string" || obj instanceof String;
};

function GetObjectChains(propName)
{
    var propNames = [];
    var o = JSON.parse(JSON.stringify(propName));
    while (o) {
        propNames = propNames.concat(Object.getOwnPropertyNames(o));
        o = Object.getPrototypeOf(o);
    }
    propNames;
    //=> [ "a", "b", "c", "constructor", "toSource", "toString", "toLocaleString", "valueOf", "watch",
    //     "unwatch", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "__defineGetter__",
    //     "__defineSetter__", "__lookupGetter__", "__lookupSetter__" ]
    // この結果は Firefox 12.0 の場合

    document.title = propNames;
}
