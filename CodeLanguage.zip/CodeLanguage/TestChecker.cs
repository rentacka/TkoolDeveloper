﻿using Jint.Parser.Ast;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jsCallEditor
{
    /// <summary>
    /// ブレークポイントテスト
    /// </summary>
    class BreakTest
    {
        public static void TestState(Jint.Parser.Ast.Program program)
        {
            foreach (var syntaxItem in program.Body)
            {
                // 関数呼び出し
                if (syntaxItem.Type == SyntaxNodes.ExpressionStatement)
                {
                    var syntax = (ExpressionStatement)syntaxItem;
                    var callExp = (CallExpression)syntax.Expression;
                    var callee = (Identifier)callExp.Callee;
                    var functionName = callee.Name;
                    var args = callExp.Arguments;

                    // 変数の追加
                }

                // 変数宣言
                if (syntaxItem is VariableDeclaration)
                {
                    var syntax = (VariableDeclaration)syntaxItem;
                    var dec = syntax.Declarations;
                }

                if (syntaxItem is BlockStatement)
                {
                    var syntax = (BlockStatement)syntaxItem;
                    var body = syntax.Body;
                }

                if (syntaxItem is CatchClause)
                {
                    var syntax = (CatchClause)syntaxItem;
                    var param = syntax.Param;
                    var body = syntax.Body;
                }

                if (syntaxItem is Jint.Parser.Ast.ForInStatement)
                {
                    var syntax = (ForInStatement)syntaxItem;
                    var leftParam = syntax.Left;
                    var rightParam = syntax.Right;
                    var body = syntax.Body;
                }

                if (syntaxItem is Jint.Parser.Ast.ForStatement)
                {
                    var syntax = (ForStatement)syntaxItem;
                    var init = syntax.Init;
                    var update = syntax.Update;
                    var body = syntax.Body;
                }

                if (syntaxItem is Jint.Parser.Ast.IfStatement)
                {
                    var syntax = (IfStatement)syntaxItem;
                    var alternate = syntax.Alternate;
                }
            }

        }
    }
}
