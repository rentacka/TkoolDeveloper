﻿namespace jsCallEditor
{
    partial class RefarenceSearcher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UnityGakushuButton = new System.Windows.Forms.Button();
            this.TkookMVGakushuButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CsharpGakushuButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.TkoolInitbutton = new System.Windows.Forms.Button();
            this.CsharpSmartbutton = new System.Windows.Forms.Button();
            this.CshparJsonbutton = new System.Windows.Forms.Button();
            this.TkoolMVJsonbutton = new System.Windows.Forms.Button();
            this.UnityJsonbutton = new System.Windows.Forms.Button();
            this.CSharpTreebutton = new System.Windows.Forms.Button();
            this.TkoolMVTreebutton = new System.Windows.Forms.Button();
            this.UnityTreebutton = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.VectorTestButton = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // UnityGakushuButton
            // 
            this.UnityGakushuButton.Location = new System.Drawing.Point(6, 59);
            this.UnityGakushuButton.Name = "UnityGakushuButton";
            this.UnityGakushuButton.Size = new System.Drawing.Size(128, 23);
            this.UnityGakushuButton.TabIndex = 0;
            this.UnityGakushuButton.Text = "Unityのリファレンス学習";
            this.UnityGakushuButton.UseVisualStyleBackColor = true;
            this.UnityGakushuButton.Click += new System.EventHandler(this.UnityGakushuButton_Click);
            // 
            // TkookMVGakushuButton
            // 
            this.TkookMVGakushuButton.Location = new System.Drawing.Point(6, 6);
            this.TkookMVGakushuButton.Name = "TkookMVGakushuButton";
            this.TkookMVGakushuButton.Size = new System.Drawing.Size(155, 23);
            this.TkookMVGakushuButton.TabIndex = 1;
            this.TkookMVGakushuButton.Text = "ツクールMVのリファレンス学習";
            this.TkookMVGakushuButton.UseVisualStyleBackColor = true;
            this.TkookMVGakushuButton.Click += new System.EventHandler(this.TkookMVGakushuButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(169, 41);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 19);
            this.textBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(169, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(167, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(417, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "C:\\Program Files\\Unity 5.6.0b3\\Editor\\Data\\Documentation\\en\\ScriptReference";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(350, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "↑UnityインストーラーでDocumentをインストールした場所(32bit対応済み";
            // 
            // CsharpGakushuButton
            // 
            this.CsharpGakushuButton.Location = new System.Drawing.Point(17, 172);
            this.CsharpGakushuButton.Name = "CsharpGakushuButton";
            this.CsharpGakushuButton.Size = new System.Drawing.Size(60, 23);
            this.CsharpGakushuButton.TabIndex = 9;
            this.CsharpGakushuButton.Text = "C#学習";
            this.CsharpGakushuButton.UseVisualStyleBackColor = true;
            this.CsharpGakushuButton.Click += new System.EventHandler(this.CsharpGakushuButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(178, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "label5";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 49);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(417, 290);
            this.tabControl1.TabIndex = 11;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.TkoolInitbutton);
            this.tabPage2.Controls.Add(this.CsharpSmartbutton);
            this.tabPage2.Controls.Add(this.CshparJsonbutton);
            this.tabPage2.Controls.Add(this.TkoolMVJsonbutton);
            this.tabPage2.Controls.Add(this.UnityJsonbutton);
            this.tabPage2.Controls.Add(this.CSharpTreebutton);
            this.tabPage2.Controls.Add(this.TkoolMVTreebutton);
            this.tabPage2.Controls.Add(this.UnityTreebutton);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(409, 264);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Html構造化";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // TkoolInitbutton
            // 
            this.TkoolInitbutton.Location = new System.Drawing.Point(30, 98);
            this.TkoolInitbutton.Name = "TkoolInitbutton";
            this.TkoolInitbutton.Size = new System.Drawing.Size(94, 23);
            this.TkoolInitbutton.TabIndex = 7;
            this.TkoolInitbutton.Text = "Html初期化";
            this.TkoolInitbutton.UseVisualStyleBackColor = true;
            this.TkoolInitbutton.Click += new System.EventHandler(this.TkoolInitbutton_Click);
            // 
            // CsharpSmartbutton
            // 
            this.CsharpSmartbutton.Location = new System.Drawing.Point(133, 55);
            this.CsharpSmartbutton.Name = "CsharpSmartbutton";
            this.CsharpSmartbutton.Size = new System.Drawing.Size(75, 23);
            this.CsharpSmartbutton.TabIndex = 6;
            this.CsharpSmartbutton.Text = "C#最適化";
            this.CsharpSmartbutton.UseVisualStyleBackColor = true;
            this.CsharpSmartbutton.Click += new System.EventHandler(this.CsharpSmartbutton_Click);
            // 
            // CshparJsonbutton
            // 
            this.CshparJsonbutton.Location = new System.Drawing.Point(30, 55);
            this.CshparJsonbutton.Name = "CshparJsonbutton";
            this.CshparJsonbutton.Size = new System.Drawing.Size(84, 23);
            this.CshparJsonbutton.TabIndex = 5;
            this.CshparJsonbutton.Text = "C#圧縮Json";
            this.CshparJsonbutton.UseVisualStyleBackColor = true;
            this.CshparJsonbutton.Click += new System.EventHandler(this.CshparJsonbutton_Click);
            // 
            // TkoolMVJsonbutton
            // 
            this.TkoolMVJsonbutton.Location = new System.Drawing.Point(133, 98);
            this.TkoolMVJsonbutton.Name = "TkoolMVJsonbutton";
            this.TkoolMVJsonbutton.Size = new System.Drawing.Size(94, 23);
            this.TkoolMVJsonbutton.TabIndex = 4;
            this.TkoolMVJsonbutton.Text = "ツクールMVJson";
            this.TkoolMVJsonbutton.UseVisualStyleBackColor = true;
            this.TkoolMVJsonbutton.Click += new System.EventHandler(this.TkoolMVJsonbutton_Click);
            // 
            // UnityJsonbutton
            // 
            this.UnityJsonbutton.Location = new System.Drawing.Point(30, 12);
            this.UnityJsonbutton.Name = "UnityJsonbutton";
            this.UnityJsonbutton.Size = new System.Drawing.Size(75, 23);
            this.UnityJsonbutton.TabIndex = 3;
            this.UnityJsonbutton.Text = "UnityJson";
            this.UnityJsonbutton.UseVisualStyleBackColor = true;
            this.UnityJsonbutton.Click += new System.EventHandler(this.UnityJsonbutton_Click);
            // 
            // CSharpTreebutton
            // 
            this.CSharpTreebutton.Location = new System.Drawing.Point(214, 55);
            this.CSharpTreebutton.Name = "CSharpTreebutton";
            this.CSharpTreebutton.Size = new System.Drawing.Size(75, 23);
            this.CSharpTreebutton.TabIndex = 2;
            this.CSharpTreebutton.Text = "C#構造化";
            this.CSharpTreebutton.UseVisualStyleBackColor = true;
            this.CSharpTreebutton.Click += new System.EventHandler(this.CSharpTreebutton_Click);
            // 
            // TkoolMVTreebutton
            // 
            this.TkoolMVTreebutton.Location = new System.Drawing.Point(238, 98);
            this.TkoolMVTreebutton.Name = "TkoolMVTreebutton";
            this.TkoolMVTreebutton.Size = new System.Drawing.Size(108, 23);
            this.TkoolMVTreebutton.TabIndex = 1;
            this.TkoolMVTreebutton.Text = "ツクールMV構造化";
            this.TkoolMVTreebutton.UseVisualStyleBackColor = true;
            this.TkoolMVTreebutton.Click += new System.EventHandler(this.TkoolMVTreebutton_Click);
            // 
            // UnityTreebutton
            // 
            this.UnityTreebutton.Location = new System.Drawing.Point(214, 12);
            this.UnityTreebutton.Name = "UnityTreebutton";
            this.UnityTreebutton.Size = new System.Drawing.Size(75, 23);
            this.UnityTreebutton.TabIndex = 0;
            this.UnityTreebutton.Text = "Unity構造化";
            this.UnityTreebutton.UseVisualStyleBackColor = true;
            this.UnityTreebutton.Click += new System.EventHandler(this.UnityTreebutton_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.TkookMVGakushuButton);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.UnityGakushuButton);
            this.tabPage1.Controls.Add(this.CsharpGakushuButton);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.VectorTestButton);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(409, 264);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "学習";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // VectorTestButton
            // 
            this.VectorTestButton.Location = new System.Drawing.Point(286, 39);
            this.VectorTestButton.Name = "VectorTestButton";
            this.VectorTestButton.Size = new System.Drawing.Size(75, 23);
            this.VectorTestButton.TabIndex = 4;
            this.VectorTestButton.Text = "ベクトル表示";
            this.VectorTestButton.UseVisualStyleBackColor = true;
            this.VectorTestButton.Click += new System.EventHandler(this.VectorTestButton_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(409, 264);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Html初期化後にここを開くこと";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // RefarenceSearcher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 338);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Name = "RefarenceSearcher";
            this.Text = "RefarenceSearcher";
            this.Load += new System.EventHandler(this.RefarenceSearcher_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button UnityGakushuButton;
        private System.Windows.Forms.Button TkookMVGakushuButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button CsharpGakushuButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button CSharpTreebutton;
        private System.Windows.Forms.Button TkoolMVTreebutton;
        private System.Windows.Forms.Button UnityTreebutton;
        private System.Windows.Forms.Button CshparJsonbutton;
        private System.Windows.Forms.Button TkoolMVJsonbutton;
        private System.Windows.Forms.Button UnityJsonbutton;
        private System.Windows.Forms.Button CsharpSmartbutton;
        private System.Windows.Forms.Button VectorTestButton;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button TkoolInitbutton;
    }
}