﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word2Vec.Net;

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Jint.Parser;
using Jint.Parser.Ast;
using System.IO;

namespace jsCallEditor
{
    /// <summary>
    /// 言語ベクトル
    /// </summary>
    class DistanceWorld2
    {
        /// <summary>
        /// ベクター化 trandata.bin,result.bin,vocab.bin をファイル出力
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static Distance ToVectorFromFile(string source)
        {

            string outputFileName = Application.StartupPath + "/result.bin";
            string vocabFileName = Application.StartupPath + "/vocab.bin";

            var word2Vec = Word2VecBuilder.Create()
                .WithTrainFile(source)// Use text data to train the model;
                .WithOutputFile(outputFileName)//Use to save the resulting word vectors / word clusters
                .WithSize(200)//Set size of word vectors; default is 100
                .WithSaveVocubFile(vocabFileName)//The vocabulary will be saved to <file>
                .WithDebug(2)//Set the debug mode (default = 2 = more info during training)
                .WithBinary(1)//Save the resulting vectors in binary moded; default is 0 (off)
                .WithCBow(1)//Use the continuous bag of words model; default is 1 (use 0 for skip-gram model)
                .WithAlpha(0.05f)//Set the starting learning rate; default is 0.025 for skip-gram and 0.05 for CBOW
                .WithWindow(7)//Set max skip length between words; default is 5
                .WithSample((float)1e-3)//Set threshold for occurrence of words. Those that appear with higher frequency in the training data twill be randomly down-sampled; default is 1e-3, useful range is (0, 1e-5)
                .WithHs(0)//Use Hierarchical Softmax; default is 0 (not used)
                .WithNegative(5)//Number of negative examples; default is 5, common values are 3 - 10 (0 = not used)
                .WithThreads(5)//Use <int> threads (default 12)
                .WithIter(5)//Run more training iterations (default 5)
                .WithMinCount(5)//This will discard words that appear less than <int> times; default is 5
                .WithClasses(0)//Output word classes rather than word vectors; default number of classes is 0 (vectors are written)
                .Build();

            word2Vec.TrainModel();

            var distance = new Distance(outputFileName);

            return distance;
        }

        /// <summary>
        /// ベクター化 trandata.bin,result.bin,vocab.bin をファイル出力
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static Distance ToVectorFile(string source)
        {
            string trainfile = Application.StartupPath + "/trandata.bin";
            System.IO.StreamWriter sw = new System.IO.StreamWriter(trainfile,
                false,
                System.Text.Encoding.UTF8);
            sw.Write(source);
            sw.Close();

            return ToVectorFromFile(trainfile);
        }

        public static string OptimiseParseJson(string source)
        {
            var Tokens = ToToken(source);

            foreach (var token in Tokens)
            {
                token.LineNumber = null;
                token.Location = null;
                token.Range = null;
            }

            var json = ToJson(Tokens);
            string line;
            StringBuilder sb = new StringBuilder();
            using (var sr = new StringReader(json))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.Contains(quote("location")) == false &&
                        line.Contains(quote("lineNumber")) == false &&
                         line.Contains(quote("range")) == false &&
                         line.Contains(quote("lineStart")) == false)
                    {
                        sb.AppendLine(line);
                    }
                }
            }

            return sb.ToString();
        }

        static List<Token> ToToken(string source)
        {
            var jParser = new JavaScriptParser();

            ParserOptions option = new ParserOptions();
            // エラーでもできるだけ変換
            option.Tolerant = true;

            // ノイズ除去
            option.Comment = false;
            option.Tokens = true;
            var program = jParser.Parse(source, option);

            return program.Tokens;
        }

        static string quote(string target)
        {
            return @"""" + target + @"""" + ":";
        }

        public static string ToJson(object program)
        {
            var settings = new JsonSerializerSettings()
            {
                ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver(),
            };
            var converter = new StringEnumConverter();
            settings.Converters.Add(converter);
            // Formatting.IndentedでJsonを整形
            var result = JsonConvert.SerializeObject(program, Formatting.Indented, settings);

            return result;
        }
    }
}
