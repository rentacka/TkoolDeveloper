using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using TkoolJsonData;

namespace jsCallEditor
{
	internal class TkoolJson
	{
		public class CsData
		{
			public string name;

			public string path;

			public string data;
		}

		private static string DataDir
		{
			get
			{
				return Path.Combine(MainForm.prjDir, "data\\");
			}
		}

		public Animations[] DeSerializeAnimations()
		{
			string str = "Animations";
			return this.DeserializeFromFile<Animations[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Tilesets[] DeSerializeTilesets()
		{
			string str = "Tilesets";
			return this.DeserializeFromFile<Tilesets[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public States[] DeSerializeStates()
		{
			string str = "States";
			return this.DeserializeFromFile<States[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public CommonEvents[] DeSerializeCommonEvents()
		{
			string str = "CommonEvents";
			return this.DeserializeFromFile<CommonEvents[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Items[] DeSerializeItems()
		{
			string str = "Items";
			return this.DeserializeFromFile<Items[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Actors[] DeSerializeActors()
		{
			string str = "Actors";
			return this.DeserializeFromFile<Actors[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Armors[] DeSerializeArmors()
		{
			string str = "Armors";
			return this.DeserializeFromFile<Armors[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Classes[] DeSerializeClasses()
		{
			string str = "Classes";
			return this.DeserializeFromFile<Classes[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Enemies[] DeSerializeEnemies()
		{
			string str = "Enemies";
			return this.DeserializeFromFile<Enemies[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Troops[] DeSerializeTroops()
		{
			string str = "Troops";
			return this.DeserializeFromFile<Troops[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Weapons[] DeSerializeWeapons()
		{
			string str = "Weapons";
			return this.DeserializeFromFile<Weapons[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public TkoolSystem DeSerializeSystem()
		{
			string str = "System";
			return this.DeserializeFromFile<TkoolSystem>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Skills[] DeSerializeSkills()
		{
			string str = "Skills";
			return this.DeserializeFromFile<Skills[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public MapInfoItem[] DeSerializeMapInfos()
		{
			string str = "MapInfos";
			return this.DeserializeFromFile<MapInfoItem[]>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public Map DeSerializeMapFromFile(int mapID)
		{
			string str = "Map" + mapID.ToString("000");
			return this.DeserializeFromFile<Map>(Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public T DeserializeFromFile<T>(string path)
		{
			return JsonConvert.DeserializeObject<T>(TkoolJson.ReadText(path));
		}

		public static void DeSerializeMapFile(int mapID)
		{
			TkoolJson.DeSerializeMapFile(mapID, false);
		}

		public static TkoolJson.CsData DeSerializeMapFile(int mapID, bool isReadCsFile)
		{
			Directory.CreateDirectory(Application.StartupPath + "\\data");
			string text = "Map" + mapID.ToString("000");
			TkoolJson.DeSerializeFile(Path.Combine(TkoolJson.DataDir, text + ".json"), Application.StartupPath + "\\data", text, text);
			if (isReadCsFile)
			{
				string path = Application.StartupPath + "\\data\\" + text + ".cs";
				string data = TkoolJson.ReadText(path);
				return new TkoolJson.CsData
				{
					name = text,
					path = path,
					data = data
				};
			}
			return null;
		}

		public static void DeSerializeMapInfosFile()
		{
			string text = "MapInfos";
			TkoolJson.DeSerializeFile(Path.Combine(TkoolJson.DataDir, text + ".json"), Application.StartupPath + "\\data", text, text);
		}

		public static void DeSerializeFile(string jsonPath, string foldaPath, string nameSpace, string className)
		{
			TkoolJson.DeSerializeFile(jsonPath, foldaPath, nameSpace, className);
		}

		public void SerializeTkoolData(Animations[] mapObj)
		{
			string str = "Animations";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Actors[] mapObj)
		{
			string str = "Actors";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Armors[] mapObj)
		{
			string str = "Armors";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Classes[] mapObj)
		{
			string str = "Classes";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(CommonEvents[] mapObj)
		{
			string str = "CommonEvents";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Enemies[] mapObj)
		{
			string str = "Enemies";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Items[] mapObj)
		{
			string str = "Items";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Skills[] mapObj)
		{
			string str = "Skills";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(States[] mapObj)
		{
			string str = "States";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Tilesets[] mapObj)
		{
			string str = "Tilesets";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(TkoolSystem mapObj)
		{
			string str = "TkoolSystem";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Troops[] mapObj)
		{
			string str = "Troops";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(Weapons[] mapObj)
		{
			string str = "Weapons";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeTkoolData(MapInfoItem[] mapObj)
		{
			string str = "MapInfos";
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeMapFile(Map mapObj, int mapID)
		{
			string str = "Map" + mapID.ToString("000");
			this.SerializeFile(mapObj, Path.Combine(TkoolJson.DataDir, str + ".json"));
		}

		public void SerializeFile(object obj, string fileName)
		{
			string text = JsonConvert.SerializeObject(obj);
			TkoolJson.TextWrite(fileName, text);
		}

		public string Serialize(object obj)
		{
			return JsonConvert.SerializeObject(obj);
		}

		private static void TextWrite(string path, string text)
		{
			StreamWriter expr_0C = new StreamWriter(path, false, Encoding.UTF8);
			expr_0C.Write(text);
			expr_0C.Close();
		}

		private static string ReadText(string path)
		{
			StreamReader expr_0B = new StreamReader(path, Encoding.UTF8);
			string result = expr_0B.ReadToEnd();
			expr_0B.Close();
			return result;
		}

		private static string ConvertEncoding(string src, Encoding destEnc)
		{
			Encoding expr_05 = Encoding.ASCII;
			byte[] bytes = expr_05.GetBytes(src);
			byte[] bytes2 = Encoding.Convert(expr_05, destEnc, bytes);
			return destEnc.GetString(bytes2);
		}

		private static void DynamicCsharp()
		{
		}
	}
}
