using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace jsCallEditor
{
	public static class CsarpDocJson
    {
        static string unityDocPath = null;
        private static string DataDir
		{
			get
			{
                if (unityDocPath == null)
                {
                    var unity64DocPath = @"C:\Program Files\Unity 5.6.0b3\Editor\Data\Documentation\en\ScriptReference";
                    var unity32DocPath = @"C:\Program Files (x86)\Unity 5.6.0b3\Editor\Data\Documentation\en\ScriptReference";

                    if (Directory.Exists(unity32DocPath))
                        unityDocPath = unity32DocPath;
                    if (Directory.Exists(unity64DocPath))
                        unityDocPath = unity64DocPath;
                }

                // Unity�̃��t�@�����X�t�H���_
                var docdata = Path.Combine(unityDocPath, "docdata");

                return docdata;
			}
		}

        public static void UnicodeSmartData()
        {
            string path = "csharp.data";
            var text = CsarpDocJson.ReadUtf8Text(path).Replace(@"      \", "").Replace(@"\", "").Replace(@"[""{", "[{").Replace(@"]""}", "]}").Replace(@"""{", "{").Replace(@"}""", "}").Trim().Replace("        ","").Replace("<!---->", "");

            StringBuilder builder = new StringBuilder();
            foreach (var chara in text)
                if (chara.ToString() != "?"&& !char.IsControl(chara))
                    builder.Append(chara);

            var text2 = builder.ToString();

            SaveJpText("debag.data", text2);
        }

        public static EntryHtml[] DeSerializeEntryHtml()
		{
			string str = "debag.data";
			return DeserializeFromFile<EntryHtml[]>(Path.Combine(Application.StartupPath, str));
		}

		public static T DeserializeFromFile<T>(string path)
		{
            var text = CsarpDocJson.ReadJpText(path);

            return JsonConvert.DeserializeObject<T>(text);
            //return JsonConvert.DeserializeObject<T>(CsarpDocJson.ReadText(path));
        }

        public static  void SerializeFile(object obj, string fileName)
        {
            //JsonSerializerSettings settings = new JsonSerializerSettings();
            string text = JsonConvert.SerializeObject(obj);
            SaveUtf8Text(fileName, text);
        }

        public static string Serialize(object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }

        public static void SaveJpText(string saveFileName, string text)
        {
            System.IO.StreamWriter sw = new System.IO.StreamWriter(
               Path.Combine(Application.StartupPath, saveFileName),
                false,
            System.Text.Encoding.GetEncoding("shift_jis"));
            sw.Write(text);
            sw.Close();
        }

        public static void SaveUtf8Text(string saveFileName, string text)
        {
            System.IO.StreamWriter sw = new System.IO.StreamWriter(
               Path.Combine(Application.StartupPath, saveFileName),
                false,
                Encoding.UTF8);
            sw.Write(text);
            sw.Close();
        }

        private static string ReadJpText(string path)
        {
            StreamReader expr_0B = new StreamReader(path, Encoding.GetEncoding("shift_jis"));
            string result = expr_0B.ReadToEnd();
            expr_0B.Close();
            return result;
        }

        private static string ReadUtf8Text(string path)
		{
			StreamReader expr_0B = new StreamReader(path, Encoding.UTF8);
			string result = expr_0B.ReadToEnd();
			expr_0B.Close();
			return result;
		}

		private static string ConvertEncoding(string src, Encoding destEnc)
		{
			Encoding expr_05 = Encoding.ASCII;
			byte[] bytes = expr_05.GetBytes(src);
			byte[] bytes2 = Encoding.Convert(expr_05, destEnc, bytes);
			return destEnc.GetString(bytes2);
		}
	}
}
