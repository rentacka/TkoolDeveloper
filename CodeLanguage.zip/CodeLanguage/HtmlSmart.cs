﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jsCallEditor
{
    class HtmlSmart
    {
        public static string GetHtmlTitle(HtmlAgilityPack.HtmlNode htmlDoc)
        {
            // HTMLから(複数の)titleタグを探す
            var titleNode = htmlDoc.Descendants("title").First();

            return titleNode.InnerText.Replace("\r\n", "");
        }

        public static string GetHtmlTitleClass(HtmlAgilityPack.HtmlNode htmlDoc)
        {
            string title = null;
            var titleNoe = htmlDoc.SelectSingleNode(@"//div[@class=""title""]");
            if(titleNoe != null)
                title = titleNoe.InnerText.Replace("\r\n", "");

            return title;
        }

        public class Stence
        {
            public string summury;
            public string href;
        }

        public static Stence GetHmltSummury(HtmlAgilityPack.HtmlNode htmlDoc)
        {
            var summaryNode= htmlDoc.SelectSingleNode(@"//div[@class=""summary""]");
            if (summaryNode != null)
            {
                var stenceNode = summaryNode.SelectSingleNode(@"//div[@class=""mt-sentence""]");

                string explain = null;
                if (stenceNode != null)
                {
                    var summryLinesText = stenceNode.InnerText.Replace(" ", "");

                    var htmTitle = GetHtmlTitle(htmlDoc);

                    StringBuilder summrySb = new StringBuilder();
                    System.IO.StringReader cReader = new System.IO.StringReader(summryLinesText);
                    while (cReader.Peek() >= 0)
                    {
                        // ファイルを 1 行ずつ読み込む
                        string stBuffer = cReader.ReadLine();

                        if (stBuffer.Length > 0)
                        {
                            if(htmTitle.Contains(stBuffer) == false)
                                summrySb.AppendLine(stBuffer);
                        }
                    }
                    cReader.Close();

                    explain = summrySb.ToString().Replace("\r\n", ""); ;
                }

                var stenceLinkNode = summaryNode.SelectSingleNode(@"//a[@class=""mtps-internal-link""]");
                var href = stenceLinkNode.GetAttributeValue("href", "");

               var stence = new Stence();
                stence.summury = explain;
                stence.href = href;

                return stence;
            }
            else
                return null;
        }

        public static string GetLittleHtml(string html)
        {
            StringBuilder littleHtml = new StringBuilder();
            System.IO.StringReader cReader = new System.IO.StringReader(html);
            while (cReader.Peek() >= 0)
            {
                // ファイルを 1 行ずつ読み込む
                string stBuffer = cReader.ReadLine();

                littleHtml.AppendLine(stBuffer);

                if (stBuffer.Contains("アセンブリ:"))
                {
                    break;
                }
            }
            cReader.Close();

            return littleHtml.ToString();
        }

        public static string GetNamespaseLoad(string html)
        {
            bool IsStartHtmlBuf = false;
            StringBuilder nameHtml = new StringBuilder();
            System.IO.StringReader cReader = new System.IO.StringReader(html);
            while (cReader.Peek() >= 0)
            {
                // ファイルを 1 行ずつ読み込む
                string stBuffer = cReader.ReadLine();

                if (stBuffer.Contains("名前空間:"))
                    IsStartHtmlBuf = true;

                if (IsStartHtmlBuf)
                    nameHtml.AppendLine(stBuffer);

                if (stBuffer.Contains("アセンブリ:"))
                {
                    break;
                }
            }
            cReader.Close();

            if (nameHtml.ToString().Length > 0)
            {
                HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                htmlDoc.LoadHtml(nameHtml.ToString());

                var name_link = htmlDoc.DocumentNode.SelectSingleNode(@"//a[@class=""mtps-internal-link""]");

                if (name_link != null)
                    return name_link.InnerText;
                else
                    return null;
            }
            else
                return null;
        }
    }
}
