﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Xml;
using System.ServiceModel.Syndication;
using System.IO;

//using System.Web.Razor;
//using System.Web.WebPages.Razor;
using RazorEngine;
using RazorEngine.Templating;
using RazorEngine.Text;
using RazorEngine.Compilation;
using RazorEngine.Configuration;

namespace TkoolCsharpSample
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void JavascriptCreatButton_Click(object sender, RoutedEventArgs e)
        {
            WriteHtml();
        }

        void WriteHtml()
        {
            var model = new MVscriptSharp();

            string template = File.ReadAllText("javascriptTest.cshtml");

            // ＨＴＭＬへ変換
            var result = Engine.Razor.RunCompile(new LoadedTemplateSource(template, null), "templateKey", typeof(MVscriptSharp), model);

            //変換されたテキストをログファイルとして生成
            using (var sw = new StreamWriter(System.Windows.Forms.Application.StartupPath + "/" + "test.js"))
            {
                sw.Write(result);
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
        }
    }
}
