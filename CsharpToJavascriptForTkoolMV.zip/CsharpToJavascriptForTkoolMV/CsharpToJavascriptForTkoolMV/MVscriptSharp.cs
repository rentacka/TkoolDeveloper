﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TkoolCsharpSample
{
    /// <summary>
    /// ツクールMV用のスクリプト
    /// </summary>
    public class MVscriptSharp
    {
        public string HellowWorldStr
        {
            get { return HellowWorld(true); }
        }

        public string HellowWorldStr2
        {
            get { return HellowWorld(false); }
        }


        public string HellowWorld(bool isMode)
        {
            if(isMode)
                return " eval(Hellow World);";
            else
                return " eval(Hellow World2);";
        }
    }
}
